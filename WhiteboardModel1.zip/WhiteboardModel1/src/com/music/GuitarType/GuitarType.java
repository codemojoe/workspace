package com.music.GuitarType;

public enum GuitarType {
    CLASSICAL, ACOUSTIC, ELECTRIC
}
